﻿using Microsoft.AspNetCore.Mvc;
using EventDAL.Model;
using EventDAL.Repository;
namespace MVC.Controllers
{
    public class EventController : Controller
    {
		IRepository repo;
		public EventController(IRepository repo)
		{
			this.repo = repo;
		}
        public IActionResult Index()
        {
			List<UserDetail> users = new List<UserDetail>();
			try
			{
				users = repo.GetUsersList();
			}
			catch (Exception)
			{

				throw;
			}
			return View(users);
        }

		public IActionResult Create()
		{
			return View();
		}
		[HttpPost]
		public IActionResult Create(Models.UserDetail user)
		{
			UserDetail userDetail = new UserDetail();
			try
			{
				userDetail.FirstName = user.FirstName;
				userDetail.Lastname=user.Lastname;
				userDetail.Password = user.Password;
				userDetail.EmailId = user.EmailId;

				repo.AddUser(userDetail);
			}
			catch (Exception e)
			{

				throw e;
			}
			return RedirectToAction("Index");
		}

		public IActionResult Edit(int id)
		{	
			Models.UserDetail ud= new Models.UserDetail();
			UserDetail userDetail = new UserDetail();
			try
			{
				 userDetail = repo.GetUser(id);
				ud.FirstName = userDetail.FirstName;
				ud.Lastname = userDetail.Lastname;
				ud.Password = userDetail.Password;
				ud.EmailId = userDetail.EmailId;

			}
			catch (Exception)
			{

				throw;
			}
			return View(ud);
		}
		[HttpPost]
		public IActionResult Edit(UserDetail ud)
		{
            
          
            try
			{
                repo.EditUser(ud);
			}
			catch (Exception e)
			{

				throw e;
			}
			return RedirectToAction("Index");
		}

		public IActionResult Delete(int id)
		{
			UserDetail ud= new UserDetail();
			try
			{
				ud = repo.GetUser(id);
			}
			catch (Exception e)
			{

				throw e;
			}
			return View(ud);
		}

		[HttpPost , ActionName("Delete")]

		public IActionResult DeleteUser(int id)
		{
			try
			{
				repo.Delete(id);
			}
			catch (Exception e)
			{

				throw e;
			}
			return RedirectToAction("Index");
		}
    }
}
