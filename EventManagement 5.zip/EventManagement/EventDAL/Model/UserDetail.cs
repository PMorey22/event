﻿using System.ComponentModel.DataAnnotations;

namespace EventDAL.Model
{
    public class UserDetail
    {
        [Key]
        public int Id { get; set; }

        [Required,MaxLength(35,ErrorMessage ="Lenth should be less than 35")]
        public string FirstName { get; set; }

        [Required, MaxLength(35, ErrorMessage = "Lenth should be less than 35")]
        public string Lastname { get; set; }


        [Required, MaxLength(50, ErrorMessage = "Lenth should be less than 35")]
        public string EmailId { get; set; }

        [Required, MaxLength(35, ErrorMessage = "Lenth should be less than 35"),DataType(DataType.Password)]
        public string Password { get; set; }

        [Required]
        public bool IsActive { get; set; } = true;


    }
}
