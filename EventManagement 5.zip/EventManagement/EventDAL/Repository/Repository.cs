﻿using EventDAL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventDAL.Repository
{
    public class Repository:IRepository
    {
        UserDetailDbContext context;
        public Repository()
        {
            context = new UserDetailDbContext();
        }

        public bool AddUser(UserDetail userDetail)
        {
            bool flag = false;
            try
            {
                context.UserDetails.Add(userDetail);
                context.SaveChanges();
                flag = true;
            }
            catch (Exception e)
            {

                throw e;
            }
            return flag;
        }

        public bool EditUser(UserDetail userDetail)
        {
            bool flag = false;
            try
            {
                UserDetail ud = context.UserDetails.Find(userDetail.Id);
                ud.FirstName = userDetail.FirstName;
                ud.Lastname = userDetail.Lastname;
                ud.Password = userDetail.Password;
                ud.EmailId = userDetail.EmailId;
                context.SaveChanges();
                flag = true;
            }
            catch (Exception e)
            {

                throw e;
            }
            return flag;
        }

        public UserDetail GetUser(int id) 
            {
                UserDetail userDetail = new UserDetail();
            try
            {
                userDetail = context.UserDetails.Find(id);
            }
            catch (Exception e)
            {

                throw e;
            }
            return userDetail;
            }
        public List<UserDetail> GetUsersList()
        {
            List<UserDetail> p = null;

            try
            {
                p = context.UserDetails.ToList();
            }
            catch (Exception e)
            {

                throw e;
            }
            return p;
        }

        public bool Delete(int id)
        {
            bool flag = false;
            try
            {
                UserDetail ud = context.UserDetails.Find(id);
                context.UserDetails.Remove(ud);
                context.SaveChanges();
                flag = true;
            }
            catch (Exception e)
            {

                throw e;
            }
            return flag;
        }
    }
}
